$("document").ready(function(){
  // #setProp on click
  $("#setProp").click(function(evt){
    $("#example p").css("text-decoration","overline")
                  .css("font-size", "+=1pt");
  });
  //
  $("#setProps").click(function(evt) {
    $("#example p").css({
      "font-weight" : "bold",
      "color" : "red",
      "text-decoration" : "underline"
    });
  });
  //
  $("#addCl").click(function(evt) {
    $("#example p").removeClass("pClass");
  });
  //
  $("#rmCl").click(function(evt) {
    $("#example p").removeClass("pClass");
  });
  //
  $("#toggleCl").click(function(evt) {
    $("#example p").toggleClass("pClass");
  });
});
