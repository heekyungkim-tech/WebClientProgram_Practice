$("document").ready(function(){
  var elem = $("#para1");
  elem.prev().css("border","3px solid red"); // prev elements in paral
  elem.next().css("background-color","lightgreen"); // nextelement in paral
  elem.parents().css("border","1px solid green"); // all parents that includes paral
  elem.parentsUntil($("body")).css("border", "1px solid orange");
  // starts in #example and find the if para4.
  $("#example").find("#para4").css("background-color","lightblue");

});
