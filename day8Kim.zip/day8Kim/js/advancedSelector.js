$(document).ready(function(){
  $("div > ul").css("border", "2px solid yellow");
  $("div p.a").css("border", "3px solid red");
/* The next adjacent selector 'element(prev) + element(next)' selects the next
  element if it is immediately preceded by a prev element*/
  $("ul + div").css({"background-color":"lightblue", "font-size":"200%"});
  $("#para4 ~ p").css("border", "3px solid orange");
});
