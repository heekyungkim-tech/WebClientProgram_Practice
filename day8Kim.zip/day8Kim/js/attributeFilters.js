$("document").ready(function(){
  $("p[class]").css("border", "3px solid red");
  $("p[id=para1]").css("border","3px solid green");
  $("p[id^=para]").css("background-color","lightblue");
  $("p[id^=para][lang*= en-]").css("border","3px solid blue");
})
