$("document").ready(function(){
//select paragraph that contains string 3
$("p:contains('3')").css("border","3px solid red");
// parent filter
$("p:parent").css("font-size","150%");
//select div that has p with class a
$("div:has(p[class=a])").css("border", "3px solid blue");
$("div p:first-child").css("background-color", "lightgreen");
//look for the last p that is inside of a div
$("div p:last-of-type").css("background-color", "lightblue");
//look for the 3rd p that is inside of a div
$("div p:nth-child(3)").css("background-color", "yellow");
//select every multiple of 2
$("div p:nth-child(2n)").css("background-color", "orange");
})
