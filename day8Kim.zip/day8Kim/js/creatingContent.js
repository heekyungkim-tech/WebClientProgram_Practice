$("document").ready(function(){
  document.getElementById("create").addEventListener("click", function(evt){
    createContent();
  });
  document.getElementById("change").addEventListener("click",function(evt){
    changeContent();
  });
  document.getElementById("changeAll").addEventListener("click",function(evt){
    changeAllTheContent();
  });
  // use the html() function to get the current HTML of an element
  // alert($("#example").html());
});
function createContent(){
  //use the html() function to change the content of the div
  $("#example").html("<p>Hi there!</p>");
}
function changeContent(){
  // set the text content of the last Paragraph
  var newItem = $("<p>This is a new paragraph</p>");
  $("#para1").html(newItem);
}
function changeAllTheContent(){
  $("#example p").text("<p>This is a paragraph</p>");
}
