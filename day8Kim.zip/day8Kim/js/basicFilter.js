$(document).ready(function(){
  $('#example p:first').css('color','blue');
  $('#example p:last').css('border','2px solid green');
  $('#example p:even').css('border','2px solid red'); // array index starts with zero
  $('#example p:odd').css('border','2px solid blue');

  $('.a:first').css('border', '2px solid green');
  //selecting p that is in #example except p that not in index 2
  $('#example p:not(p:eq(2))').css('border','2px solid green');
});
