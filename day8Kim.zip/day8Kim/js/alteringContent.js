$("document").ready(function(){
  // wrap function wraps content around existing
  $("#example p").wrap("<div style='color:red'/>");
  //wrap the parent elements of #example p into the given class
  $("#example p").wrapAll("<div style='color:red'/>");
  //$("#example").empty(); // clear all element in #example
  $("#example p.a, #example p.b").remove();
  $("#example p.a, #example p.b").detach(); // detach temporary remove the data
  //replace all p elements in #example that has id with the new given div
  $("<div>replaced</div>").replaceAll("#example p[id]");
  // replace from left to right
  $("#example p[id]").replaceWith("<div>replaced</div>");
})
