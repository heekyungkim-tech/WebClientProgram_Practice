$(document).ready(function(){
  $("h3").css('border','3px solid red');
  $('#para5').css('background-color','yellow');
  $('.a').css('background-color','green');
  $('li.b').css('border','3px solid pink');
});
