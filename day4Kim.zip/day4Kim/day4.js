// Day4 - Heekyung Kim
// -----creating an object in a variable-----------
var hotel = {
  // properties
  name: "Quay",
  rooms: 40,
  booked: 25,
  gym: true,
  roomTypes: ['twin','double','suite'],
  //method
  checkAvailability: function(){
    return this.rooms - this.booked;
  }
};
document. getElementById('function1').innerHTML = "Numbers of rooms available: " + hotel.checkAvailability();
document.getElementById('function1').innerHTML += "<br/> The hotel name is: " +hotel.name;
document.getElementById('function1').innerHTML += "<br/> The room type is: " +hotel.roomTypes[0];
//
// ----UPDATING AN OBJECT--------
hotel.gym = false;
document.getElementById('function1').innerHTML += "<br/> The updated gym is: " +hotel.gym;
//
hotel.roomTypes[2] = 'Master Suite';
document.getElementById('function1').innerHTML += "<br/>The updated room type are: " +hotel.roomTypes[2];
// delete a property value from a key name
delete hotel.name;
document.getElementById('function1').innerHTML += "<br/>Value of property name: " +hotel.name;
// create an array to property name
hotel.name = ['Holidays Inn','Best Western', 'Flushing Hotel'];
document.getElementById('function1').innerHTML += "<br/>The updated hotel names are: " +hotel.name;
//
//----------OBJECT CONTRUCTOR---------
function hotel1(name1, rooms1, booked1){
  this.name = name1;
  this.rooms = rooms1;
  this.booked = booked1;
  this.checkAvailability = function(){
    return this.rooms - this.booked;
  }
};
var user1 = new hotel1('QCC Inn', 20, 7);
document.getElementById('function2').innerHTML = "The name of the hotel: "+user1.name +'<br/>The total number of available rooms: '+ user1.checkAvailability();
// ---------adding and removing------
var hotel2  = {
  name: 'Park Inn',
  rooms: 120,
  booked: 77
};
document.getElementById('function3').innerHTML = "The name of the hotel: " +hotel2.name;
// add qym to object hotel2
hotel2.gym = "&#9825";
// delete booked from object hotel 2
delete hotel2.booked;
document.getElementById('function3').innerHTML += "<br/>Gym: "  +hotel2.gym;
console.log(hotel2);
//
///---------------THE BROWSER properties----------------
var browser = 'Display the height of window in pixels: ' + window.innerHeight;
browser += '<br/>Contain details of the pages that have been viewed in that window: ' + window.history;
browser += '<br/>Screen object width in pixels: ' + window.screen.width;
document.getElementById('function4').innerHTML = browser;
// object model to document object
var docText = '<br/> Display the title of a current document: ' + document.title;
document.getElementById('function4').innerHTML += docText;
// Object for strings
var string1='home sweet home!';
document.getElementById('function5').innerHTML = "The string words is: " +string1 + '<br/>Change string to uppercase: ' +string1.toUpperCase();

//-----MATH OBJECT
// create a random number between 0 and 10. this includes decimals
var ranNumber = Math.random()*10;
document.getElementById('function5').innerHTML +='<br/>The random number is: '+ranNumber;
//round the random number
var roundNumber = Math.round(ranNumber);
document.getElementById('function5').innerHTML += '<br/>The rounded random number is: rounded to the nearest integer is: ' +roundNumber;
//round ranNumber to the nearest interger
var ceilNumber = Math.ceil(ranNumber);
document.getElementById('function5').innerHTML += '<br/>The rounded UP to the nearest integer: ' +ceilNumber;
// floor
var floorNumber = Math.floor(ranNumber);
document.getElementById('function5').innerHTML += '<br/>The rounded DOWN to the nearest integer: ' +floorNumber;
//------DATE OBJECTS--------------
var todayYear = new Date();
var year1 = todayYear.getFullYear();
document.getElementById('function6').innerHTML += '<br/>Copyright &copy: ' + year1;
var year2 = 1998;
var diffYear = year1-year2;
document.getElementById('function6').innerHTML += '<br/>'+ diffYear + ' years of online experiences! ';
