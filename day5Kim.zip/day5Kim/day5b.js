//-------REPLACE TEXT NODE ------
// step1 : find the location of the node and it in a variable. For example, we want to replace the txt "Pine Nuts" with "Whole Milk"
var item = document.getElementById('two');
// step2 : locate the child of the "item" and save it in a variable. nodeValue let us to record the text value
var itemText = item.firstChild.nodeValue;
console.log(itemText);
var replaceItem = itemText.replace('Pine Nuts', 'Whole Milk')
// step3 : take the text node and replace it back to the element node
item.firstChild.nodeValue = replaceItem;

//--------DISPLAYING TEXT NODE USING textContent and innerText
//textContent: display the text as it is
//innerText: display only the visible text
//innerHTML: display the text and the HTML
var item_textContent = document.getElementById('four');
var show_textContent = item_textContent.textContent;
var show_innerText = item_textContent.innerText;
var msg = 'The text content using textContent is: '+show_textContent;
msg += '</br>The text content using innerText is: '+show_innerText;
document.getElementById('textDisplay').innerHTML = msg;

//------- REPLACING TEXT NODE USING innerHTML----------
//replace text in element id 'one' with 'Apples'
document.getElementById('one').innerHTML = 'Apples';

//------- ADDING ELEMENTS USING DON MANIPULATIONS --------
// to add element in DOM, you need to use the method appenChild
// step 1: create a new element and store it in a variable
var newElement = document.createElement('li');
//step2: create a text node for the new element and store it in a variable
var newText = document.createTextNode('Cereals');
//step3: attach the text node with the element node using appenChild
newElement.appendChild(newText);
// step 4: find the position where the new element should be
var newPosition = document.getElementsByTagName('ul')[0];
// step 5: insert the new element into its position
newPosition.appendChild(newElement);
//optional - step 6: set up a css class name to the newElement using setAttribute
newElement.setAttribute('class', 'hot');

//--------REMOVING ELEMENTS VIA DOM MANIPULATIONS------
// Example: remove the third element from my list
// step 1: locate the element node that I want to remove and save the location in a variable
var removeElement = document.getElementsByTagName('li')[2];
// step2: Store the parent node location in a variable
var containParent = removeElement.parentNode;
console.log('The remove element location: ' +removeElement);
console.log('The remove element parent Node: ' +containParent);
containParent.removeChild(removeElement);

//--------CHECK THE ATTRIBUTES AND GET ITS VALUE---------
// Example: check if the li id='one' has a class set.
var firstList = document.getElementById('one');
if (firstList.hasAttribute('class')){
  var attrName = firstList.getAttribute('class');
}
else (firstList.setAttribute('class','cool'))
document.getElementById('textDisplay').innerHTML += '<br/>The class name of the first list is: '+attrName;
