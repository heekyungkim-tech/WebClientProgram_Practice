// ------SELECTING INDIVIDUAL ELEMENTS ----
var element1 = document.getElementById('one');
console.log(element1);

//change the class value of element to cool by using the object className
element1.className = 'cool';

// ------NODELIST------
// using getElementByTagName
var element2 = document.getElementsByTagName('h2');
console.log(element2[0]); // console the first item in array h2
var element3 = document.getElementsByTagName('li');
var sizeElement3 = element3.length;
console.log('size if li is: ' +sizeElement3);

// using getElementsByClassName
var element4 = document.getElementsByClassName('hot');
var sizeElement4 = element4.length;
console.log('size if class name "hot" is: '+sizeElement4);

//using querySelectorAll
var element5 = document.querySelectorAll('li[id]');
var sizeElement5 = element5.length;
console.log('Size of element5 using querySelectorAll: '+sizeElement5);

//---------SELECTING AN ELEMENT FROM A NODELIST------
//There are two ways to select an element from a NodeList (both of these techniques require the index number of the element you want)
// 1st method: using item() method returns on indivisual node from the NODELIST
var element5Item = element5.item(1); // selecting the 2nd item in element5
console.log('2nd item in element5 is: '+element5Item);
//2nd method: array index
var element5Array = element5[2]; //selecting the 3rd item Location in element5

//-----------SELECTING AND CHANGING ELEMENTS USING THE CLASS ATTRIBUTES------
var element4 = document.getElementsByClassName('hot');
// check if the length of element4 is greater than 2. If it is greater than two, then we change the class name of the last item to be 'cool'
var lengthElement4 = element4.length;
console.log('The length of element4 is: '+lengthElement4);
if(lengthElement4>2){
  var changeElement = element4[lengthElement4-1]; //since the index starts from 6 and Length starts from 0 but the Length of an array strats from 1, then we need to subtract 1 to lengthElement4
  changeElement.className = 'cool';
}
