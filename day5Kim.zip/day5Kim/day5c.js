// ----------LOOPING INSIDE A DOM --------
// select all the elements in my list that has a class name 'hot' and change the class name to 'cool'
//step 1: get the location of the class 'hot'
var itemHot = document.querySelectorAll('li.hot');
var lengthHot = itemHot.length;
console.log(lengthHot);
//step 2: create a for loop to change each item class to 'cool'
for(var counter=1; counter<lengthHot; counter++){
  itemHot[counter].className ='cool';
}
