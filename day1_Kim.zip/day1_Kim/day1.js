var x = 10; //numerical variable
var y = 2; //numerical variable
var z = x*y; // operations
var string="red";
var stringTxt = "My name is Heekyung Kim";
console.log("The product of x*y is: " + z); // console.log will display in the web console the text
console.log("The string is: " + stringTxt);
