var price = 5;
var quantity = 20;
var total = price*quantity;
var el=document.getElementById('cost');
console.log(el); // testing the contain of variable "el"
el.textContent="The total is $" + total;
