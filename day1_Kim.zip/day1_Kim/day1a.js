//Arrays
var fruits;
fruits = ["orange", 'apples', 'peaches'];
console.log(fruits);
var mixedArray = ['cars',8,true,'mixed array'];
var mixed = mixedArray;
var value1 = mixedArray[2];
var value2 = fruits[0];
console.log(value1);
console.log(value2);

//reverse method
var reverse_mixedArray = mixed.reverse();
console.log("After reverse: ",mixed);
//console.log(reverse_mixedArray);

//Remove the first value of the mixedArray using method "shift"
mixedArray.shift();
console.log("After shift method: ",mixedArray);

//Add comma-seperated list of values of the front of the array using method "unshield"
mixedArray.unshift("NY",280);
console.log("After unshift method: ",mixedArray);

//add comma-seperated list of the end of the array using method "push"
mixedArray.push(350,"QCC")
console.log("After push method: ",mixedArray);
