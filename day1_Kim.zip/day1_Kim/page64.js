var firstName = "Heekyung";
var lastName = "Kim";
var fullName=document.getElementById('cost');
console.log(fullName); // testing the contain of variable "el"
fullName.textContent="The full name is: " + firstName +" " +lastName;
