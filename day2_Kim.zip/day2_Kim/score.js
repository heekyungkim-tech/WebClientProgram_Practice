//Calculate your course overall grade - By: Heekyung Kim
// Create three variables as exam1, exam2, exam3, and total
var exam1 = 85;
var exam2 = 100;
var exam3 = 80;
var total;
//Calcualte the total grade using this formula = exam 1=30%, exa 2=38%, and exam 3 = 32%;
total = (0.3*exam1) + (0.38*exam2) + (0.32*exam3)

//Display each exam grade and the total grade
var display = document.getElementById('testing');
display.innerHTML = 'Exam 1 grade is: '+ exam1 + '<br/>'+
'Exam 2 gade is: '+ exam2 + '<br/>'+'Exam 3 garde is: '+ exam3 + '<br/>'+
'Overall grade is: '+ total;

//use logical operators and if, else if statement to check which GPA is the overall grade
var gpa;
total = Math.round(total);
//if total is greater and equal 96 ==> gpa = A
if (total>=96){
  gpa = "Your GPA is: A";
}
else if (total>=90 && total<=95) {
  gpa = "Your GPA is: A-";
}
else if (total>=87 && total<=89) {
  gpa = "Your GPA is: B+";
}
else if (total>=84 && total<=86) {
  gpa = "Your GPA is: B";
}
else if (total>=80 && total<=83) {
  gpa = "Your GPA is: B-";
}
else if (total>=77 && total<=79) {
  gpa = "Your GPA is: C+";
}
else if (total>=74 && total<=76) {
  gpa = "Your GPA is: C";
}
else if (total>=70 && total<=73) {
  gpa = "Your GPA is: C-";
}
else if (total>=67 && total<=69) {
  gpa = "Your GPA is:D+";
}
else if (total>=64 && total<=66) {
  gpa = "Your GPA is: D";
}
else if (total>=60 && total<=63) {
  gpa = "Your GPA is: D-";
}
else if (total<=59) {
  gpa = "Your GPA is: F";
}
else{
  msg = " ";
}
var display1 = document.getElementById('gpa');
display1.textContent = gpa;

// -----For Loop---------
var scores = [85,100,80];
var arrayLenght = scores.length;
var msg='';
var i; // counter in your for Loop

for(i=0; i<arrayLenght; i++){
  //first run i=0
  var display2 =document.getElementById('forLoop');
  display2.innerHTML +="<br/> Exam "+ (i+1)+" = "+ scores[i];
}

//While Loop => write a program that will show a multipllication table of 3
var tableNum =3;
var initialMul =1; // initial multiplier
var product;
while (initialMul<=5) {
  product = initialMul * tableNum;
  var display3 = document.getElementById('whileLoop');
  display3.innerHTML +="<br/> "+initialMul+" x "+tableNum+" = "+product;
  initialMul++; // incarease initialMul by 1
}
