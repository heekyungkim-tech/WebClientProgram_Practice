var x = 10;
var y = 8;

var equalNumber;
//Check if x is equal to y
if(x==y){
  equalNumber = x +" is equal to "+ y;
}
else if(x>y){
  equalNumber = x +" is greater than "+ y;
}
else if(x<y){
  equalNumber = x +" is less than "+ y;
}
else{
  equalNumber = "Invalid Entry!";
}
console.log(equalNumber)
var result=document.getElementById('testing');
result.textContent=equalNumber;
