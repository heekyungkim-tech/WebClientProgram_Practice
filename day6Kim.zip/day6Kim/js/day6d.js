//------SUPPORTING OLDER VERSION OF INTERNET EXPLORER (PAGE 258-259)---
// If-else 5-8 internet Explorere did not support addEventListener, it used its own method 'attachEvent()'
// Example: create a program that will check the minimum legnth apply to username and also use 'attachEvent' in case that the browser does not support 'addEventListener'
var elUsername = document.getElementById('username');
var elMsg = document.getElementById('feedback');
function checkUsername(minLength){
  if(elUsername.value.length<minLength){
    elMsg.innerHTML = '&#9888 Username must be ' +minLength+' characters or more';
  }
  else{
    elMsg.innerHTML = 'Username &#10004';
  }
}
//user if else statement to check if the username can be used with addEventListener
if (elUsername.addEventListener){
  elUsername.addEventListener('focusout',function(){checkUsername(6)},false);
}
else{
  elUsername.attachEvent('focusout',function(){checkUsername(6)},false); //IE
}
