// -----EVEN LISTENERS (PAGE 254-255)-----
// Example: the program will check if the user entered at least 5 characters in username, otherwise it will display a warning message

// Create a function that will check the number of characters entered in username
function checkUsername(){
  var elementMsg = document.getElementById('feedback'); // store location to display
  var elUsername = document.getElementById('username'); // store the location of the element where the username is going to be typed
  if (elUsername.value.length<5) {
    elementMsg.innerHTML = '&#9888 Username must be at least 5 characters!';
  }
  else{
    elementMsg.innerHTML = ' ';
  }
}
var checkFunction = document.getElementById('username');
checkFunction.addEventListener('blur',checkUsername,false);
