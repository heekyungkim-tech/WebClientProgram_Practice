// -----MOUSE EVENT - CLICK (Page 276 - 277)-----
// Example: when the webpage is loaded, display a warning message
// previous exercise from file day6e.js
var elUsername = document.getElementById('username');
var elMsg = document.getElementById('feedback');
function checkUsername(minLength){
  if(elUsername.value.length<minLength){
    elMsg.innerHTML = '&#9888 Username must be ' +minLength+' characters or more';
  }
  else{
    elMsg.innerHTML = 'Username &#10004';
  }
}
elUsername.addEventListener('focusout',function(){checkUsername(6)},false);

// load event
function setup(){
  elUsername.focus();
}
window.addEventListener('load',setup,false); //window to specify that we are targeting the browser window.
// SESIZE EVENT
function resizeWindow(){
  elMsg.innerHTML = "Your window size has been changed! ";
}
window.addEventListener('resize', resizeWindow,false);

//CREATE THE HTML WINDOW FOR THE message
var msg='<div class="header"><a id="close" href="#">Close X</a><div>';
msg+= '<div id="msgNote"><h2> System Maintenance</h2>';
msg+= '<hr/>Our serveres are being updated between 3am and 4am.<br/>';
msg+= 'We are sorry for any inconvenience! </div>';
// create a new division for the background-color
var elNote = document.createElement('div');
elNote.setAttribute('id','note');
elNote.innerHTML = msg;
// need to attach elNote to the body of your html document
document.body.appendChild(elNote);
//create a function to close the note message
function dismissNote(){
  document.body.removeChild(elNote);
}
var elClose = document.getElementById('close');
elClose.addEventListener('click',dismissNote,false);
