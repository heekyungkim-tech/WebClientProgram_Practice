// -----USER INTERFACE EVENTS (Page 272 - 273)-----
// Example: create a program that when the webpage is loaded, the click-mouse will be focuses on username
// previous exercise from file day6c.js
var elUsername = document.getElementById('username');
var elMsg = document.getElementById('feedback');
function checkUsername(minLength){
  if(elUsername.value.length<minLength){
    elMsg.innerHTML = '&#9888 Username must be ' +minLength+' characters or more';
  }
  else{
    elMsg.innerHTML = 'Username &#10004';
  }
}
elUsername.addEventListener('focusout',function(){checkUsername(6)},false);

// load event
function setup(){
  elUsername.focus();
}
window.addEventListener('load',setup,false); //window to specify that we are targeting the browser window.
// SESIZE EVENT
function resizeWindow(){
  elMsg.innerHTML = "Your window size has been changed! ";
}
window.addEventListener('resize', resizeWindow,false);
