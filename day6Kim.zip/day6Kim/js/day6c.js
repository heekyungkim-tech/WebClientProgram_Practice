// ----------USING PARAMETERS WITH HANDLERS AND LISTENERS (Page 256-257)------
// Example: create a function with a minimum length variable
var elUsername = document.getElementById('username');
var elMsg = document.getElementById('feedback');
function checkUsername(minLength){
  if(elUsername.value.length<minLength){
    elMsg.innerHTML = '&#9888 Username must be ' +minLength+' characters or more';
  }
  else{
    elMsg.innerHTML = 'Username &#10004';
  }
}
elUsername.addEventListener('focusout',function(){checkUsername(6)},false);
