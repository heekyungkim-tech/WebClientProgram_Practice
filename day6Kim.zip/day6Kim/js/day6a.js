// -----TRADITIONAL DOM EVEN HANDLERS (PAGE 252 - 253)---
// Example: the program will check if the user entered at least 5 characters in username, otherwise it will display a warning message

// Create a function that will check the number of characters entered in username
function checkUsername(){
  var elementMsg = document.getElementById('feedback'); // store location to display
  var elUsername = document.getElementById('username'); // store the location of the element where the username is going to be typed
  if (elUsername.value.length<5) {
    elementMsg.innerHTML = '&#9888 Username must be at least 5 characters!';
  }
  else{
    elementMsg.innerHTML = ' ';
  }
}
// when you click on username field, it will call for the function
var checkFunction = document.getElementById('username');
checkFunction.onfocus = checkUsername;
// 'onblur' event is active when the element loses focus
// 'onfocus' event is active when the element gains focus
