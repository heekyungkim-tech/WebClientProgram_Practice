//Day 3- Heekyung Kim
// -----do while loop// create a program that will show the multiplication table for variable "table" 6 times starting from 1
var table=2;
var i=1; //starting counter
var msg='';

do{
  msg += i + ' x ' +table+ ' = '+(i*table)+'<br/>';
  i++;
  console.log(msg);
} while(i<=6)
document.getElementById('doWhile').innerHTML = msg;
// ---------switch statement ---------
// create a program that use the "switch" statement to check four levels: high, middle, low, and none. The high level will be in between 100 and 85, middle level will be in between 84 and 60, low level will be in between 59 and below, any other cases belongs to level "none";

var level = 90;
var displayLevel = ''
switch (true) {
  case level>=85 &&level<=100:
    displayLevel ="High level";
    break;
  case level>=60 &&level<=84:
    displayLevel ="Middle level";
    break;
  case level<=59:
    displayLevel ="Low level";
    break;
  default:
    displayLevel = "None of the above!";
    break;
}
document.getElementById('switch').innerHTML ="<br/>The entered level is: "+level+'<br/>'+displayLevel;

//-----FUNCTIONS--------
// functions without argument
var a = 20;
function sum1(){
  var a = 30;
  var b = 10;
  var x = a+b;
  return x;
}
document.getElementById('function1').innerHTML = "This is a function sample without argument<br/><br/> The return value is: "+sum1();

//function with argument - write a program using function that will calculate the area of a rectangle given the width and the height
var width;
var height;

function calculateArea(width, height){
  var area = width*height;
  return area;
}
document.getElementById('function2').innerHTML = "This is a function sample with argument<br/><br/> The area of a rectangle is: "+calculateArea(4,3);

//function that returns information in an array. This function will calculate the area and the volume
var width1, height1, depth1;

function getSize(width1, height1, depth1){
  var area1 = width1*height1;
  var volume1 = width1*height1*depth1;
  var sizes = [area1,volume1];
  return sizes;
}
document.getElementById('function3').innerHTML = "The volume is: "+getSize(4,2,5)[1] +"<br/>";
document.getElementById('function3').innerHTML += "The area is: "+getSize(4,2,5)[0] +"<br/>";

//-----IMEDIATEDLY INVOKED FUNCTION EXPRESSIONS (IIFE) ==> save a function in a variable

var area2 = (function(){
  var width2 = 12;
  var height2 = 3;
  return width2 * height2;
}
);
document.getElementById('function3').innerHTML += "The area of variable area2 is: " + area2();
